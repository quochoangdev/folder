﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QL_NhaHang
{
    public partial class frm_HoaDon : Form
    {
        LopDungChung lopchung;

        public frm_HoaDon()
        {
            InitializeComponent();
            lopchung = new LopDungChung();

        }


        private void HoaDon_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }


        public void LoadGrid()
        {
            String sqlGrid = "select HD.MaHoaDon, HD.MaMon, HD.NgayLap ,HD.SoLuong, MA.DonGia,(HD.SoLuong * MA.DonGia) AS ThanhTien from  HOADON1 HD inner join MONAN MA ON HD.MaMon = MA.MaMon";
            dataGridView1.DataSource = lopchung.LoadDaTa(sqlGrid);
        }



        private void btn_tongHd_Click_1(object sender, EventArgs e)
        {
            String sqlDem = "select COUNT (*) from HOADON1";
            txt_tongHoaDon.Text = lopchung.Scalar(sqlDem).ToString();
        }

        private void btn_tao_Click(object sender, EventArgs e)
        {
            string maMon = txt_maMon.Text;

            if (CheckMaMonExists(maMon))
            {

                String sqlThem = "insert into HOADON1 values('" + txt_maHd.Text + "', " +
               "Convert(Datetime,'" + dateTimePicker1.Value + "',103),  '" + txt_soLuong.Text + "','" + txt_maMon.Text + "')";
                lopchung.Nonquery(sqlThem);
                LoadGrid();

            }
            else
            {
                MessageBox.Show("Mã món không tồn tại trong cơ sở dữ liệu.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool CheckMaMonExists(string maMon)
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=F:\\QL_NhaHang\\QL_NhaHang\\NhaHang.mdf;Integrated Security=True";
            string query = "SELECT COUNT(*) FROM MONAN WHERE MaMon = @MaMon";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaMon", maMon);
                    conn.Open();
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }


        private void btn_sua_Click(object sender, EventArgs e)
        {
            String sqlSua = "update HOADON1 set NgayLap = Convert(Datetime,'" + dateTimePicker1.Value + "',103)," +
               "SoLuong = '" + txt_soLuong.Text + "'," +
               "MaMon = '" + txt_maMon.Text + "' where MaHoaDon = '" + txt_maHd.Text + "'";
            lopchung.Nonquery(sqlSua);
            LoadGrid();
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            String sqlXoa = "delete from HOADON1 where MaHoaDon = '" + txt_maHd.Text + "'";
            lopchung.Nonquery(sqlXoa);
            LoadGrid();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_maHd.Text = dataGridView1.CurrentRow.Cells["MaHoaDon"].Value.ToString();
            dateTimePicker1.Text = dataGridView1.CurrentRow.Cells["NgayLap"].Value.ToString();
            txt_maMon.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txt_soLuong.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();


        }

        private void btn_timHd_Click(object sender, EventArgs e)
        {

            String sqlTim = "select HD.MaHoaDon, HD.MaMon, HD.NgayLap ,HD.SoLuong, MA.DonGia,(HD.SoLuong * MA.DonGia) AS ThanhTien from HOADON1 HD inner join MONAN MA ON HD.MaMon = MA.MaMon where MaHoaDon like '%" + txt_tim.Text + "%' or HD.MaMon like '%" + txt_tim.Text + "%'";
            dataGridView1.DataSource = lopchung.LoadDaTa(sqlTim);
        }

        private void btn_tongTien_Click(object sender, EventArgs e)
        {
            decimal tongTien = TinhTongTien();
            txt_tongTien.Text = TongTienSangVND(tongTien);
        }

        private decimal TinhTongTien()
        {
            decimal tongTien = 0;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow)
                {
                    object value = row.Cells["ThanhTien"].Value;
                    if (value != null && value != DBNull.Value)
                    {
                        tongTien += Convert.ToDecimal(value);
                    }
                }
            }

            return tongTien;
        }

        private string TongTienSangVND(decimal tongTien)
        {
            return string.Format("{0:#,##0} VND", tongTien);
        }

        private void btn_quayLai_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (Application.OpenForms["Menu"] == null)
            {
                Menu frm_S = new Menu();
                frm_S.Show();
            }
            else Application.OpenForms["Menu"].Show();
        }
    }
}
