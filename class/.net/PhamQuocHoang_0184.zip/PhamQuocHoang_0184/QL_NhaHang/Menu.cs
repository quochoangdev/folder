﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QL_NhaHang
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = DateTime.Now.ToString();
        }

        private void btn_thucAn_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frm_MonAn"] == null)
            {
                this.Visible = false;
                frm_MonAn ma = new frm_MonAn();
                ma.ShowDialog();
                this.Visible = true;
            }
            else Application.OpenForms["frm_MonAn"].Activate();
        }

       

        private void btn_hoaDon_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["frm_HoaDon"] == null)
            {
                this.Visible = false;
                frm_HoaDon hd = new frm_HoaDon();
                hd.ShowDialog();
                this.Visible = true;
            }
            else Application.OpenForms["frm_HoaDon"].Activate();
        }
    }
}
