﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QL_NhaHang
{
    public partial class frm_DangNhap : Form
    {
        LopDungChung lopchung;
    
        public frm_DangNhap()
        {
            InitializeComponent();
            lopchung = new LopDungChung();

        }

        private void btn_dangNhap_Click(object sender, EventArgs e)
        {
            String sqlDN = "select count (*) from TAIKHOAN " +
              "where TaiKhoan = '" + txt_tk.Text + "' and MatKhau = '" + txt_mk.Text + "'";
            int kq = (int)lopchung.Scalar(sqlDN);
            if (kq >= 1)
            {
                if (Application.OpenForms["Menu"] == null)
                {
                    this.Visible = false;
                    Menu hd = new Menu();
                    hd.ShowDialog();
                    this.Visible = true;
                }
                else Application.OpenForms["frm_HoaDon"].Activate();
            }
            else MessageBox.Show("Sai tên ĐN hoặc MK");
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            if (Application.OpenForms["frm_DangKy"] == null)
            {
                frm_DangKy frm_L = new frm_DangKy();
                frm_L.Show();
            }
            else Application.OpenForms["frm_DangKy"].Show();
        }
    }
}
