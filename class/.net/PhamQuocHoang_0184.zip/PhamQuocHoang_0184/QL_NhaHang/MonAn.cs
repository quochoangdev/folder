﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QL_NhaHang
{
    public partial class frm_MonAn : Form
    {
        LopDungChung lopchung;
        public frm_MonAn()
        {
            InitializeComponent();
            lopchung = new LopDungChung();

        }

        private void MonAn_Load(object sender, EventArgs e)
        {        
            LoadCombo();
            LoadGrid();
        }


        public void LoadCombo()
        {
            String sqlcomBo = "select * from LOAI";
            cb_loai.DataSource = lopchung.LoadDaTa(sqlcomBo);
            cb_loai.DisplayMember = "TenLoai";
            cb_loai.ValueMember = "MaLoai";
        }
        public void LoadGrid()
        {
            String sqlGrid = "select * from MONAN";
            dataGridView1.DataSource = lopchung.LoadDaTa(sqlGrid);
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            String sqlThem = "insert into MONAN values('" + txt_maMon.Text + "', N'" + txt_tenMon.Text + "' , '"+txt_donGia.Text+ "','" + cb_loai.SelectedValue + "', '"+txt_hinhAnh.Text+"')";
            pictureBox.Image.Save(duongdan + txt_hinhAnh.Text);
            lopchung.Nonquery(sqlThem);
            LoadGrid();
        }

        string duongdan = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName + "\\HINHANH\\";

        private void btn_sua_Click(object sender, EventArgs e)
        {
            String sqlSua = "update MONAN set TenMon = N'" + txt_tenMon.Text + "'," +
               "MaLoai = '" + cb_loai.SelectedValue + "'," +
               "DonGia = '"+txt_donGia.Text+"'," +
               "TenHinh = '"+txt_hinhAnh.Text+"'  where MaMon = '" + txt_maMon.Text + "'";
            pictureBox.Image.Save(duongdan + txt_hinhAnh.Text);
            lopchung.Nonquery(sqlSua);
            LoadGrid();
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            String sqlXoa = "delete from MONAN where MaMon = '" + txt_maMon.Text + "'";
            lopchung.Nonquery(sqlXoa);
            LoadGrid();
        }

        
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_maMon.Text = dataGridView1.CurrentRow.Cells["MaMon"].Value.ToString();
            txt_tenMon.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txt_donGia.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txt_hinhAnh.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            pictureBox.ImageLocation = duongdan + txt_hinhAnh.Text;
            tam = 1;
            cb_loai.SelectedValue = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            tam = 0;
        }
        int tam = 0;

        private void cb_loai_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tam == 0)
            {
                String sqlGrid = "select * from MONAN where MaMon = '" + cb_loai.SelectedValue + "'";
                dataGridView1.DataSource = lopchung.LoadDaTa(sqlGrid);
            }
        }

        private void btn_load_Click(object sender, EventArgs e)
        {
            LoadGrid();

        }

        private void btn_tim_Click(object sender, EventArgs e)
        {
            String sqlTim = "select * from MONAN where MaMon like '%" + txt_tim.Text + "%' or TenMon like '%" + txt_tim.Text + "%'";
            dataGridView1.DataSource = lopchung.LoadDaTa(sqlTim);
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Hãy chọn hình";
            ofd.Filter = "Tất cả đuôi|*.*|Đuôi jpg|*.jpg|Đuôi png|*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
                pictureBox.Image = Image.FromFile(ofd.FileName);
        }

        private void btn_quayLai_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (Application.OpenForms["Menu"] == null)
            {
                Menu frm_S = new Menu();
                frm_S.Show();
            }
            else Application.OpenForms["Menu"].Show();
        }
    }
}
