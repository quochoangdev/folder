﻿
namespace CS464_Lab_5
{
    partial class frm_nhapMang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_mangA = new System.Windows.Forms.TextBox();
            this.txt_tongCacSoLe = new System.Windows.Forms.TextBox();
            this.txt_tongCacSoChan = new System.Windows.Forms.TextBox();
            this.txt_tongCacSoMangA = new System.Windows.Forms.TextBox();
            this.btn_tinhToan = new System.Windows.Forms.Button();
            this.btn_lamMoi = new System.Windows.Forms.Button();
            this.btn_thoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(140, 73);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mang A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(140, 165);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tong Cac So Le";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(140, 270);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(182, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tong Cac So Chan";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(140, 362);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tong Cac So Mang A";
            // 
            // txt_mangA
            // 
            this.txt_mangA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mangA.Location = new System.Drawing.Point(457, 69);
            this.txt_mangA.Margin = new System.Windows.Forms.Padding(4);
            this.txt_mangA.Name = "txt_mangA";
            this.txt_mangA.Size = new System.Drawing.Size(465, 30);
            this.txt_mangA.TabIndex = 4;
            // 
            // txt_tongCacSoLe
            // 
            this.txt_tongCacSoLe.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tongCacSoLe.Location = new System.Drawing.Point(457, 158);
            this.txt_tongCacSoLe.Margin = new System.Windows.Forms.Padding(4);
            this.txt_tongCacSoLe.Name = "txt_tongCacSoLe";
            this.txt_tongCacSoLe.Size = new System.Drawing.Size(132, 30);
            this.txt_tongCacSoLe.TabIndex = 5;
            // 
            // txt_tongCacSoChan
            // 
            this.txt_tongCacSoChan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tongCacSoChan.Location = new System.Drawing.Point(457, 262);
            this.txt_tongCacSoChan.Margin = new System.Windows.Forms.Padding(4);
            this.txt_tongCacSoChan.Name = "txt_tongCacSoChan";
            this.txt_tongCacSoChan.Size = new System.Drawing.Size(132, 30);
            this.txt_tongCacSoChan.TabIndex = 6;
            // 
            // txt_tongCacSoMangA
            // 
            this.txt_tongCacSoMangA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tongCacSoMangA.Location = new System.Drawing.Point(457, 354);
            this.txt_tongCacSoMangA.Margin = new System.Windows.Forms.Padding(4);
            this.txt_tongCacSoMangA.Name = "txt_tongCacSoMangA";
            this.txt_tongCacSoMangA.Size = new System.Drawing.Size(132, 30);
            this.txt_tongCacSoMangA.TabIndex = 7;
            // 
            // btn_tinhToan
            // 
            this.btn_tinhToan.Location = new System.Drawing.Point(145, 446);
            this.btn_tinhToan.Margin = new System.Windows.Forms.Padding(4);
            this.btn_tinhToan.Name = "btn_tinhToan";
            this.btn_tinhToan.Size = new System.Drawing.Size(160, 44);
            this.btn_tinhToan.TabIndex = 8;
            this.btn_tinhToan.Text = "Tinh Toan";
            this.btn_tinhToan.UseVisualStyleBackColor = true;
            this.btn_tinhToan.Click += new System.EventHandler(this.btn_tinhToan_Click);
            // 
            // btn_lamMoi
            // 
            this.btn_lamMoi.Location = new System.Drawing.Point(457, 446);
            this.btn_lamMoi.Margin = new System.Windows.Forms.Padding(4);
            this.btn_lamMoi.Name = "btn_lamMoi";
            this.btn_lamMoi.Size = new System.Drawing.Size(160, 44);
            this.btn_lamMoi.TabIndex = 9;
            this.btn_lamMoi.Text = "Lam Moi";
            this.btn_lamMoi.UseVisualStyleBackColor = true;
            this.btn_lamMoi.Click += new System.EventHandler(this.btn_lamMoi_Click);
            // 
            // btn_thoat
            // 
            this.btn_thoat.Location = new System.Drawing.Point(764, 446);
            this.btn_thoat.Margin = new System.Windows.Forms.Padding(4);
            this.btn_thoat.Name = "btn_thoat";
            this.btn_thoat.Size = new System.Drawing.Size(160, 44);
            this.btn_thoat.TabIndex = 10;
            this.btn_thoat.Text = "Thoat";
            this.btn_thoat.UseVisualStyleBackColor = true;
            this.btn_thoat.Click += new System.EventHandler(this.btn_thoat_Click);
            // 
            // frm_nhapMang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btn_thoat);
            this.Controls.Add(this.btn_lamMoi);
            this.Controls.Add(this.btn_tinhToan);
            this.Controls.Add(this.txt_tongCacSoMangA);
            this.Controls.Add(this.txt_tongCacSoChan);
            this.Controls.Add(this.txt_tongCacSoLe);
            this.Controls.Add(this.txt_mangA);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_nhapMang";
            this.Text = "frm_tinhTongLe";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_nhapMang_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_mangA;
        private System.Windows.Forms.TextBox txt_tongCacSoLe;
        private System.Windows.Forms.TextBox txt_tongCacSoChan;
        private System.Windows.Forms.TextBox txt_tongCacSoMangA;
        private System.Windows.Forms.Button btn_tinhToan;
        private System.Windows.Forms.Button btn_lamMoi;
        private System.Windows.Forms.Button btn_thoat;
    }
}